###**PG08 T1 A1: Bio Web Page**
Submitted by: <pg15teddy> Teddy Nasahachart
Date: <date submitted>
Version: [if applicable]
----------
< Description of what my project does - edit and replace this line >
[demo] http://dev.pgwm.vfs.local/~pg15teddy/bio/index.html

####**Download/Install**
---------
 - Browse to demo link
 - [Download Zip] Download through Moodle
 - You can uncompressed zip by right click on a zip file then choose Extract


####**How to use**
--------
In this web page show the use of flex box in html5 and css by creating my bio