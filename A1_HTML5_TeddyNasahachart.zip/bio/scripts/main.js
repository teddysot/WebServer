/*
Template App
(c) Copyright 2019 Scott Henshaw, In cooperation with VFS, All right reserved.
*/
'use strict';

// JavaScript goes here...
let a = 6; // a number
a += 5;

let  title = "Hello";
title += " World";

console.log("Message: " + title);

let el = document.querySelector('#element-id');
el.innerHTML = title;